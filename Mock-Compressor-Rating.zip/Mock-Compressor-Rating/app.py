from flask import Flask, render_template, request
import random
import os

app = Flask(__name__)

# Mock compressor models for dropdown
COMPRESSOR_MODELS = [f"Model-mock-{i}" for i in range(1, 9)]

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    
    if request.method == 'POST':
        # Get form inputs
        model = request.form.get('model')
        te = float(request.form.get('te'))
        ct = float(request.form.get('ct'))
        sub = float(request.form.get('sub'))
        spht = float(request.form.get('spht'))
        ta = float(request.form.get('ta'))
        
        # Generate mock capacity and power values
        # In the real app, this would call your Fortran calculations
        capacity = random.uniform(50000, 220000)  # BTU/HR
        power = random.uniform(800, 2000)  # Watts
        
        result = {
            'model': model,
            'te': round(te, 1),
            'ct': round(ct, 1),
            'sub': round(sub, 1),
            'spht': round(spht, 1),
            'ta': round(ta, 1),
            'capacity': round(capacity),  # Round to nearest whole number
            'power': round(power)  # Round to nearest whole number
        }
    
    return render_template('index.html', compressor_models=COMPRESSOR_MODELS, result=result)

if __name__ == '__main__':
    # Try multiple ports in case of conflicts on Windows
    possible_ports = [3000, 5000, 5050, 8000, 8888]
    
    # Get port from environment variable if specified
    env_port = os.environ.get('PORT')
    if env_port:
        possible_ports.insert(0, int(env_port))
    
    for port in possible_ports:
        try:
            # Listen on all interfaces (0.0.0.0) for container compatibility
            app.run(host='0.0.0.0', port=port, debug=False)
            break
        except OSError as e:
            print(f"Port {port} is in use, trying next port...")
            if port == possible_ports[-1]:
                print("All ports are in use. Please specify an available port using the PORT environment variable.")
                raise e